
<?php $__env->startSection('content'); ?>
<div class="fullwidthbanner-container">
					<div class="fullwidthbanner">
						<div class="bannercontainer" >
					    <div class="banner" >
								<ul>
									<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<!-- THE FIRST SLIDE -->
									<li data-transition="boxfade" data-slotamount="20" class="active-revslide" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0;">
						            <div class="slotholder" style="width:100%;height:100%;" data-duration="undefined" data-zoomstart="undefined" data-zoomend="undefined" data-rotationstart="undefined" data-rotationend="undefined" data-ease="undefined" data-bgpositionend="undefined" data-bgposition="undefined" data-kenburns="undefined" data-easeme="undefined" data-bgfit="undefined" data-bgfitend="undefined" data-owidth="undefined" data-oheight="undefined">
													<div class="tp-bgimg defaultimg" data-lazyload="undefined" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" data-lazydone="undefined" src="source/image/slide/<?php echo e($sl->image); ?>" data-src="source/image/slide/<?php echo e($sl->image); ?>" style="background-color: rgba(0, 0, 0, 0); background-repeat: no-repeat; background-image: url('source/image/slide/<?php echo e($sl->image); ?>'); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit;">
													</div>
												</div>

						       		</li>
						       		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>

						<div class="tp-bannertimer"></div>
					</div>
				</div>
				<!--slider-->
	</div>
	<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="beta-products-list">
							<h4>Sản phẩm mới</h4>
							<div class="beta-products-details">
								<div class="clearfix"></div>
							</div>

							<div class="row">
								<?php $__currentLoopData = $new_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-3">
									<div class="single-item">
										<?php if($new->promotion_price!=0): ?>
										<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
										<?php endif; ?>
										<div class="single-item-header"><br>
											<a href="chi-tiet-san-pham/<?php echo e($new->id); ?>"><img src="source/image/product/<?php echo e($new->image); ?>" alt="" height="250px"><br></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($new->name); ?></p>
											<p class="single-item-price" style= " font-size: 20px" >
												<?php if($new->promotion_price==0): ?>
												<span class="flash-sale"><?php echo e(number_format($new->unit_price)); ?>đ</span>
												<?php else: ?>
												<span class="flash-del"><?php echo e(number_format($new->unit_price)); ?>đ</span>
												<span class="flash-sale"><?php echo e(number_format($new->promotion_price)); ?>đ</span>
												<?php endif; ?>
											</p>
										</div>
									<div class="single-item-caption" id='id_<?php echo e($new->id); ?>'>
											<a class="add-to-cart pull-left" href="add-to-cart/<?php echo e($new->id); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="chi-tiet-san-pham/<?php echo e($new->id); ?>">Chi tiết <i class="fa fa-chevron-right"></i></a>
										<div id='danhgia_<?php echo e($new->id); ?>'>	
											 <input type="number" min="1" max="5" value="3">&#9733
											 
											 <button onClick="F('<?php echo e($new->id); ?>')">Danh gia</button>
										</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
							<div class="row" style= " font-size: 20px"><br><?php echo e($new_product->links()); ?> </div>
						</div> <!-- .beta-products-list -->

						<div class="space50">&nbsp;</div>

						<div class="beta-products-list">
							<h4>Sản phẩm khuyến mãi</h4>
							<div class="beta-products-details">
								<div class="clearfix"></div>
							</div>
							<div class="row">
								<?php $__currentLoopData = $sanpham_khuyenmai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-3">
									<div class="single-item">
										<div class="single-item-header"><br>
											<a href="chi-tiet-san-pham/<?php echo e($spkm->id); ?>"><img src="source/image/product/<?php echo e($spkm->image); ?>" alt="" height="250px"><br></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($spkm->name); ?></p>
											<p class="single-item-price"style= " font-size: 20px">
												<span class="flash-del"><?php echo e(number_format($spkm->unit_price)); ?>đ</span>
												<span class="flash-sale"><?php echo e(number_format($spkm->promotion_price)); ?>đ</span>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="add-to-cart/<?php echo e($spkm->id); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="chi-tiet-san-pham/<?php echo e($spkm->id); ?>">Chi tiết <i class="fa fa-chevron-right"></i></a>
											<div id='danhgia_<?php echo e($spkm->id); ?>'>	
												<input type="number" min="1" max="5" value="3">&#9733
												
												<button onClick="F('<?php echo e($spkm->id); ?>')">Danh gia</button>
										   </div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							</div>
							<div class="row" style= " font-size: 20px"><br><?php echo $sanpham_khuyenmai->links(); ?> </div>
						</div> <!-- .beta-products-list -->
					</div>
				</div> <!-- end section with sidebar and main content -->


			</div> <!-- .main-content -->
		</div> <!-- #content -->
		
<?php $__env->stopSection(); ?>
<script>
	function F(id)
	{
		n= jQuery('#id_'+id+' input[type=number]').val();
	// n = jQuery('#id_' + id+' input[type=radio]:checked').val();
		jQuery.ajax(
			{
			url:'danhgia',
			type:'POST',
			data:"id="+id+"&diem="+n+"&_token=<?php echo e(csrf_token()); ?>",
			success:function(s)
			{
				console.log(s);
				if (s==1)
				{alert('Cam on...');
				jQuery('#danhgia_'+id).hide(5000);

				}
				else 
				alert('co 1  loi...');
			}
			}
		);
	}
</script>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Banhang\resources\views/page/trangchu.blade.php ENDPATH**/ ?>