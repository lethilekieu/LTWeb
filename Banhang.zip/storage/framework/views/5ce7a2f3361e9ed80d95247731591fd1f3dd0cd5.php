 
<?php $__env->startSection('admin_content'); ?>
 <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Sửa sản phẩm
                        </header>
                        <div class="panel-body">
                            <?php $__currentLoopData = $edit_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="position-center">
                                <form role="form"action="<?php echo e(URL::to('update-product/'.$edit_value->id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên sản phẩm</label>
                                    <input type="text" name="product_name" class="form-control" id="exampleInputEmail1"value="<?php echo e($edit_value->name); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Mô tả </label>
                                    <textarea style="resize: none" rows="5" class="form-control" name="product_desc"  id="exampleInputPassword1" > <?php echo e($edit_value->description); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Hình ảnh</label>
                                    <input type="file" name="product_image" class="form-control" id="exampleInputEmail1" >
                                    <img src="<?php echo e(URL::to('source/image/product/'.$edit_value->image)); ?>" height="100" width="100" >
                                </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Loại sản phẩm</label>
                                  <select name="category_product" class="form-control input- m-bot15">
                                    <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cate->id==$edit_value->id_type): ?>
                                    <option selected value="<?php echo e($cate->id); ?>"> <?php echo e($cate->name); ?></option>
                                    <?php else: ?>
                                     <option value="<?php echo e($cate->id); ?>"> <?php echo e($cate->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                 
                                </select>  
                            </div>
                             <div class="form-group">
                                    <label for="exampleInputEmail1">Giá gốc</label>
                                    <input type="text" name="product_unit_price" class="form-control" value="<?php echo e($edit_value->unit_price); ?>" id="exampleInputEmail1" >
                            </div>
                              <div class="form-group">
                                    <label for="exampleInputEmail1">Giá khuyến mãi</label>
                                    <input type="text" value="<?php echo e($edit_value->promotion_price); ?>" name="product_promo" class="form-control" id="exampleInputEmail1" >
                            </div>
                               <div class="form-group">
                                <label for="exampleInputPassword1">Đơn vị</label>
                                  <select name="unit" value="<?php echo e($edit_value->unit); ?>" class="form-control input- m-bot15">
                                    <option> Hộp</option>
                                    <option>Cái</option>                                   
                                </select>
                            </div>
                            <button type="submit" name ="add_product" class="btn btn-info">Cập nhật</button>
                            </form>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>

            </div>
           
</div>
<?php $__env->stopSection(); ?>      
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Banhang\resources\views/admin/edit_product.blade.php ENDPATH**/ ?>